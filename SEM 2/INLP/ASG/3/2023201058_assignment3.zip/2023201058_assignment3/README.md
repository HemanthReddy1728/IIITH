train.csv and test.csv should be in this directory

File running:
```python
python [fileName].py
```

https://drive.google.com/drive/folders/1KiNglxH5IcVdY61mwXPncowZIvnb6phI?usp=drive_link


