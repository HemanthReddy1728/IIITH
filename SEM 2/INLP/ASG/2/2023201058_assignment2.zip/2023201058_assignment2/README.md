https://drive.google.com/drive/folders/1alxo7QsCqEEdpo3jF_Uti4mMbZ0yw528?usp=sharing

Execution:
 Runs the POS tagger (command line arguments
-f for FFN, -r for RNN), which should prompt for a sentence and
output its POS tags in the specified format.

python3 pos_tagger.py -f

python3 pos_tagger.py -r

input sentence:  An apple a day
an DET
apple NOUN
a DET
day NOUN
