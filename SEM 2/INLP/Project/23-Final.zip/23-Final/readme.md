The main file for the submission is `iNLP_project_main.ipynb` this is an .ipynb
the ipynb is configured to be run directly on Collab with appropriate manipulation of source data paths. 
The rest of ipynb files are data exploration and experiments conducted.
Find link to necessary location in the google drive from the `ProjectReport-Team23.pdf`
