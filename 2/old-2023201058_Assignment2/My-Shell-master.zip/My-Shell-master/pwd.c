#include "headers.h"

void pwd()
{
	printf("%s\n",get_current_path());
	return;
}