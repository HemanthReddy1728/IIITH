# Lab Activity 1 
## Question 1
### Overview
- Implemented form submissions and dark mode

### Execution
- open .html file

### Assumption
- First Assumption
- Second Assumption

***

