# Lab Activity 4 
## Question 1
### Overview
- divides two numbers and prits result as a decimal

### Execution
- MySQL workbench

### Assumption
- SET @num1 = 12;
- SET @num2 = 7;
values should be changed in these two lines for different results



***

## Question 2
### Overview
- Prints customer's name and customer's city of those whose payment is greater than the amount being taken in as parameter

### Execution
- MySQL workbench

### Assumption
- CALL Name_City(5000); 
- New values should be given in above line in code (replacing 5000) for different results

***

## Question 3
### Overview
- Prints customer's name, country and grade whole agent's code (the parameter) starts in a similar way

### Execution
- MySQL workbench

### Assumption
- CALL NCGA('A00%'); 
- Change agent's code substring in above part of code to get different results

***