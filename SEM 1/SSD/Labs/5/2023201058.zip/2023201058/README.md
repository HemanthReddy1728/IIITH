# Lab Activity 5

## Question 1

### Overview

- Made a non-authorized login page which shows a movie trailer on login

### Execution

- Open index.html in browser, enter any username and password and click login, it goes to trailer page

### Assumption

- None
