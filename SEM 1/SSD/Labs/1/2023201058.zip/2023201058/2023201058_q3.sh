#!/bin/bash

man whereis | grep -i "search for binaries" -B 1