Q1:
If file contains odd no. of lines, my code prints middlemost line
Ex: 5 lines file -> 3rd line printed
If file contains even no. of lines, my code prints last line of 1st half (n/2 th) of the file
Ex: 10 lines file -> 5th line printed

Q3:
Prints the matching line only after printing the line which is one line before the matching line in the whereis command's description
So, prev line first, matching line next
