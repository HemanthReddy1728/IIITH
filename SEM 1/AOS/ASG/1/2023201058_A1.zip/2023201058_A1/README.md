Q1

Code Execution:
$ g++ 2023201058_A1_Q1.cpp
$ ./a.out <input file name or path>

Output file directory: 
Assignment1_1 (in same folder or location as 2023201058_A1_Q1.cpp)
Output file name: 
1_<input file name>
Output file path wrt cpp file:
./Assignment1_1/1_<input file name>

Working Procedure:
The input file is opened in read-only mode. The output file's directory is created first  with read-write-execute permissions and then output file's created next woth read-write pemissions. The output file's opened in read-write mode. I calculated input file size using lseek command with seek_end flag. An output pointer is placed at the start of output file using lseek command again but with seek_set flag. I also initialised file reading progress to zero. I have initialised a character buffer or buffer array and it's size to square root value of input file size for convenience. While the input file size is greater than buffer size what I did is:
1. Dragged the pointer from EOF (for now) of input file to buffer size amount of bytes backward (or leftside) in the input file
2. Read buffer size amount of characters from input file pointer's location.
3. The read system call puts back pointer in it's previous location (EOF for now)
4. The amount of bytes/characters read is also being added to progress
5. Put the read characters into buffer via read command
6. Reversed the buffer via simple for loop
7. As the input file's pointer went back to it's previous location, we drag it backward (or leftside) again by the same amount of buffer size bytes 
8. Wrote the reversed buffer into the output file via write system call which took outputfiledescriptor, buffer array, buffersize as arguments.
9. Looped all the above instructions by decrementing inputfilesize by buffersize until inputfilesize becomes less than buffersize

Now we can't use buffer as it'll read error values combined with remaining amount of input files characters to be read. So I initialised a new buffer of size of 1 character. Using this unit-size buffer I continued above procedure (without reversal step as size of buffer = 1) and decrementing input file size by 1 each time the loop runs.

Hence the input file has been reversed and put into output file. Finally we close both input and output files.

Q2

Code Execution:
$ g++ 2023201058_A1_Q2.cpp
$ ./a.out <input file name or path> <start_index> <end_index>

Output file directory: 
Assignment1_2 (in same folder or location as 2023201058_A1_Q2.cpp)
Output file name: 
2_<input file name>
Output file path wrt cpp file:
./Assignment1_2/2_<input file name>

Working Procedure:
Same procedure as in Q1 but is repeated 3 times with changes. So in total we have 6 while loops in code. 1st while loop takes care of reversal of input file text until start index only using big memory buffers. Some unread residue remains. 2nd while loop does the same but with unit-byte-size-buffers  acting on the residue left by first while loop. For now input file upto starting index is reversed.
We shouldn't do reversal step in 3rd and 4th while loops where we try to access content b/w start index and end index in the input file. So I appropriately chaged the lseek, read, and write commands inputs from negative to positive values so seeking of input file is done from left to right instead of usual right to left. Again after the end index (5th and 6th while loops) we do same procedure as 1st and 2nd loops until EOF to revese this content.
Hence the input file has been partially reversed and put into output file. Finally we close both input and output files.

Q3

Code Execution:
$ g++ 2023201058_A1_Q3.cpp
$ ./a.out <newfile's path> <oldfile's path> <directory path of new file>

GIVE PATHS ONLY AS ALL 3 ARGUMENTS. FILE NAMES MAYN'T WORK.

Output:
Directory existence check (Y/N)
File reversal check (Y/N)
Check of permissions (rwx values) of Owner-Group-Others for newfile (Y/N) (total 9 times)
Check of permissions (rwx values) of Owner-Group-Others for oldfile (Y/N) (total 9 times)
Check of permissions (rwx values) of Owner-Group-Others for directory (Y/N) (total 9 times)

Working Procedure:
1. Directory existence check AND 
We use stat system call (function which returns information about a file), stat data structure and following flags:
Because tests of the above form are common, additional macros are defined by POSIX to allow the test of the file type in st_mode to be written more concisely:
S_ISREG(m)  is it a regular file?
S_ISDIR(m)  directory?
S_ISCHR(m)  character device?
S_ISBLK(m)  block device?
S_ISFIFO(m) FIFO (named pipe)?
S_ISLNK(m)  symbolic link?  (Not in POSIX.1-1996.)
S_ISSOCK(m) socket?  (Not in POSIX.1-1996.)

I used S_ISDIR() for directory existence check

3. Check of permissions:
The following mask values are defined for the file mode component of the st_mode field:
Flags 	            Description 
S_IRWXU     00700   owner has read, write, and execute permission
S_IRUSR     00400   owner has read permission
S_IWUSR     00200   owner has write permission
S_IXUSR     00100   owner has execute permission

S_IRWXG     00070   group has read, write, and execute permission
S_IRGRP     00040   group has read permission
S_IWGRP     00020   group has write permission
S_IXGRP     00010   group has execute permission

S_IRWXO     00007   others (not in group) have read, write, and execute permission
S_IROTH     00004   others have read permission
S_IWOTH     00002   others have write permission
S_IXOTH     00001   others have execute permission

I used S_IRUSR, S_IWUSR, S_IXUSR, S_IRGRP, S_IWGRP, S_IXGRP, S_IROTH, S_IWOTH, S_IXOTH flags to check permissions of files if they existed on given paths

2. File reversal check:
I calculated & compared the file sizes using lseek with SEEK_END flag. If unequal they can't be reversed files. If equal, then I proceed to check the contents of the files. Similar to Q1 I read the contents of the both files part by parts (using while loop) into 2 seperate buffers and compared the contents of buffers letter by letter (using for loop). If there's even 1 mismatch of characters, that means the files are not reverse to each other in any way.


