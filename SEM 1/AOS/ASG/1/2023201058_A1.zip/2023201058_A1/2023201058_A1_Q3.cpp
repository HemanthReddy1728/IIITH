// #include <sys/types.h>
#include <sys/stat.h>
// #include <stdio.h>
// #include <stdlib.h>
// #include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
// #include <string.h>
// #include <string>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    // Input Arguments Check
    if (argc != 4) 
    {
        // fprintf(stderr, "Usage: %s <pathname>\n", argv[0]);
        write(1, "Excess Arguments Or Required Argument Missing\n", 47);
        write(1, "Try again\n", 10);
        exit(1);
    }

    // Initialising permissions (stat data structure) and some local flag values
    struct stat permissions;
    int newfileflag = 1, oldfileflag = 1, directoryflag = 1, exactreverseflag = 1;

    // Opening the input and output files
    int newfiledescriptor = open(argv[1], O_RDONLY);
    int oldfiledescriptor = open(argv[2], O_RDONLY);
    
    // Checking existence of new file argv[1]
    if (newfiledescriptor < 0)
    {
        newfileflag = -1;
    }

    // Checking existence of old file argv[2]
    if (oldfiledescriptor < 0)
    {
        oldfileflag = -1;
    }

    // PART 1

    // Checking existence of directory argv[3]
    cout << "Directory is created: ";
    if (stat(argv[3], &permissions) == 0 && S_ISDIR(permissions.st_mode))
    {
        cout << "Yes" << endl;
        // directoryflag = 1;
    }
    else
    {
        cout << "No" << endl;
        directoryflag = -1;
    }


    // PART 2

    // Checking whether new and old files are reverse of each other
    cout << "Whether file contents are reversed in newfile: ";

    // File existence flags
    if (newfileflag == 1 && oldfileflag == 1)
    {
        // Initialising file sizes
        const unsigned long long newfilesize = lseek(newfiledescriptor, 0, SEEK_END);
        const unsigned long long oldfilesize = lseek(oldfiledescriptor, 0, SEEK_END);
        lseek(newfiledescriptor, 0, SEEK_SET);

        // Checking file size equality
        if (newfilesize != oldfilesize)
        {
            exactreverseflag = -1;
            cout << "No" << endl;
        }

        // Checking/Comparing file contents with each other
        if (exactreverseflag == 1)
        {
            // Storing Input/Old file's Total size
            unsigned long long dumbsize = oldfilesize;

            // Progress counter initialized
            double progress = 0;

            // Two Big Buffers Initialized (one for each file)
            unsigned long long buffersize = ceil(sqrt(newfilesize));
            char* c_oldfile = (char*)calloc(buffersize, sizeof(char));
            char* c_newfile = (char*)calloc(buffersize, sizeof(char));

            while (dumbsize > 0)
            {
                if (dumbsize > buffersize)
                {
                    // Reading from old file and storing into it's respective buffer
                    lseek(oldfiledescriptor, -buffersize, SEEK_CUR);
                    progress += read(oldfiledescriptor, c_oldfile, buffersize);
                    // cout << "\033[2J\033[1;1H";
                    // cout <<  (double) (progress/ (double) inputfilesize) * 100 << "%" << endl;

                    // for (unsigned long long i = 0; i < ceil(buffersize/2); i++)
                    // {
                    //     char temp = c[i];
                    //     c[i] = c[buffersize-1-i];
                    //     c[buffersize-1-i] = temp;
                    // }

                    // Reading from old file and storing into it's respective buffer
                    read(newfiledescriptor, c_newfile, buffersize);

                    // Checking/Comparing files buffer contents with each other
                    for (unsigned long long i = 0; i < buffersize; i++)
                    {
                        // Even 1 Mismatched character means NOT exact reversal
                        if(c_oldfile[i] != c_newfile[buffersize - 1 - i])
                        {
                            exactreverseflag = -1;
                            // cout << "No" << endl;
                            break;
                        }
                    }
                    if (exactreverseflag == -1)
                    {
                        cout << "No" << endl;
                        break;
                    }

                    lseek(oldfiledescriptor, -buffersize, SEEK_CUR);
                    // write(outputfiledescriptor, c, buffersize);

                    dumbsize-=buffersize;
                }

                else
                {
                    // Two Unit byte buffer initialized(one for each file)
                    char* d_oldfile = (char*)calloc(1, sizeof(char));
                    char* d_newfile = (char*)calloc(1, sizeof(char));

                    while (dumbsize > 0)
                    {
                        // Reading from old file and storing into it's respective buffer
                        lseek(oldfiledescriptor, -1, SEEK_CUR);
                        progress += read(oldfiledescriptor, d_oldfile, 1);

                        // cout << "\033[2J\033[1;1H";
                        // cout <<  (double) (progress/ (double) inputfilesize) * 100 << "%" << endl;

                        // for (int i = 0; i < 5; i++)
                        // {
                        //     char temp = c[i];
                        //     c[i] = c[10-1-i];
                        //     c[10-1-i] = temp;
                        // }

                        // Reading from new file and storing into it's respective buffer
                        read(newfiledescriptor, d_newfile, 1);

                        // Mismatched character means NOT exact reversal
                        if(*d_oldfile != *d_newfile)
                        {
                            exactreverseflag = -1;
                            break;
                        }
                        lseek(oldfiledescriptor, -1, SEEK_CUR);
                        // write(outputfiledescriptor, d, 1);

                        dumbsize-=1; 
                    }           
                    if (exactreverseflag == -1)
                    {
                        cout << "No" << endl;
                        break;
                    }
                }
            }
        }
        cout << "Yes" << endl;
    }
    else
    {
        exactreverseflag == -1;
        cout << "No" << endl;
    }


    // PART 3

    // Checking existence of newfile
    if(newfileflag == 1)
    {   
        if (stat(argv[1], &permissions) == 0 && S_ISREG(permissions.st_mode))
        {
            newfileflag = 1;
        }
        else
        {
            newfileflag = -1;
        }
    }


    // Checking all 9 permissions of newfile

    cout << "User has read permissions on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IRUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "User has write permission on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IWUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "User has execute permission on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IXUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has read permissions on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IRGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has write permission on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IWGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has execute permission on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IXGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has read permissions on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IROTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has write permission on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IWOTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has execute permission on newfile: ";
    if (newfileflag == 1 && stat(argv[1], &permissions) == 0 && permissions.st_mode & S_IXOTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }



    // Checking existence of oldfile
    if(oldfileflag == 1)
    {
        if (stat(argv[2], &permissions) == 0 && S_ISREG(permissions.st_mode))
        {
            oldfileflag = 1;
        }
        else
        {
            oldfileflag = -1;
        }
    }

    // Checking all 9 permissions of oldfile

    cout << "User has read permissions on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IRUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "User has write permission on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IWUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "User has execute permission on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IXUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has read permissions on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IRGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has write permission on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IWGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has execute permission on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IXGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has read permissions on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IROTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has write permission on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IWOTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has execute permission on oldfile: ";
    if (oldfileflag == 1 && stat(argv[2], &permissions) == 0 && permissions.st_mode & S_IXOTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }



    // Checking existence of directory
    if (stat(argv[3], &permissions) == 0 && S_ISDIR(permissions.st_mode))
    {
        // cout << "Yes" << endl;
        directoryflag = 1;
    }
    else
    {
        // cout << "No" << endl;
        directoryflag = -1;
    }


    // Checking all 9 permissions of directory

    cout << "User has read permissions on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IRUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "User has write permission on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IWUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "User has execute permission on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IXUSR)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has read permissions on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IRGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has write permission on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IWGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Group has execute permission on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IXGRP)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has read permissions on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IROTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has write permission on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IWOTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
    cout << "Others has execute permission on directory: ";
    if (directoryflag == 1 && stat(argv[3], &permissions) == 0 && permissions.st_mode & S_IXOTH)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }

    // Closing both input and output files
    close(newfiledescriptor);
    close(oldfiledescriptor);
    return 0;
}






