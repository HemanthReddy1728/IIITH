// #include <sys/types.h>
#include <sys/stat.h>
// #include <stdio.h>
// #include <stdlib.h>
// #include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
// #include <string.h>
// #include <string>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    // Input Arguments Check
    if (argc != 2) 
    {
        // fprintf(stderr, "Usage: %s <pathname>\n", argv[0]);
        write(1, "Excess Arguments Or Required Argument Missing\n", 47);
        write(1, "Try again\n", 10);
        exit(1);
    }

    // Opening the input file & Extracting it's name
    // int inputfiledescriptor = open("kinput.txt", O_RDONLY);
    int inputfiledescriptor = open(argv[1], O_RDONLY);
    string inputfilename, inputfilepath = string(argv[1]);
    long long inputfilepathlength = inputfilepath.length();
    for (long long i = inputfilepathlength - 1; i > -1 ; i--)
    {
        if (inputfilepath[i] == '/')
        {
            if(i == inputfilepathlength - 1)
            {
                write(1, "Input is not a file\n", 20);
                write(1, "Try again\n", 10);
                exit(1);
            }
            inputfilename = inputfilepath.substr(i + 1);
            break;
        }
    }
    if (inputfilename.length() == 0)
    {
        inputfilename = inputfilepath;
    }


    // Making Output file's residence directory
    mkdir("./Assignment1_1", 0700);
    

    // Creating Output file
    // int outputfiledescriptor = open(("./Assignment1_1/2_" + string("kinput.txt")).c_str(), O_CREAT | O_RDWR | O_TRUNC, 0600);
    int outputfiledescriptor = open(("./Assignment1_1/1_" + inputfilename).c_str(), O_CREAT | O_RDWR | O_TRUNC, 0600);


    // Checking Files Existence
    if (inputfiledescriptor < 0 || outputfiledescriptor < 0)
    {
        write(1, "Wrong or non-existent file given as command line input\n", 56);
        write(1, "Try again\n", 10);
        remove(("./Assignment1_1/1_" + inputfilename).c_str());
        // rmdir("./Assignment1_1");
        exit(1);
    }


    // Storing Input file's size
    const unsigned long long inputfilesize = lseek(inputfiledescriptor, 0, SEEK_END);
    unsigned long long dumbsize = inputfilesize;


    // Placing pointer at output file's start
    lseek(outputfiledescriptor, 0, SEEK_SET);

    // Progress counter initialized
    double progress = 0;

    // char* c = (char*)calloc(1, sizeof(char));
    // while (dumbsize >= 0)
    // {
    //     progress += read(inputfiledescriptor, c, 1);
    //     cout << "\033[2J\033[1;1H";
    //     cout <<  (double) (progress/ (double) inputfilesize) * 100 << "%" << endl;
    //     lseek(inputfiledescriptor, -2, SEEK_CUR);
    //     write(outputfiledescriptor, c, 1);
    //     dumbsize--;
    // }


    // Big Buffer Initialized
    unsigned long long buffersize = ceil(sqrt(inputfilesize));
    char* c = (char*)calloc(buffersize, sizeof(char));


    while (dumbsize > 0)
    {
        if (dumbsize > buffersize)
        {
            // Reading from input file and storing into buffer
            lseek(inputfiledescriptor, -buffersize, SEEK_CUR);
            progress += read(inputfiledescriptor, c, buffersize);

            // Progress display
            cout << "\033[2J\033[1;1H";
            cout <<  (double) (progress/ (double) inputfilesize) * 100 << "%" << endl;

            // Reversing content inside buffer
            for (unsigned long long i = 0; i < ceil(buffersize/2); i++)
            {
                char temp = c[i];
                c[i] = c[buffersize-1-i];
                c[buffersize-1-i] = temp;
            }

            // Writing reversed content into output file
            lseek(inputfiledescriptor, -buffersize, SEEK_CUR);
            write(outputfiledescriptor, c, buffersize);

            dumbsize-=buffersize;
        }
        else
        {
            // Unit byte buffer initialized
            char* d = (char*)calloc(1, sizeof(char));
            while (dumbsize > 0)
            {
                // Reading from input file and storing into buffer
                lseek(inputfiledescriptor, -1, SEEK_CUR);
                progress += read(inputfiledescriptor, d, 1);

                // Progress display
                cout << "\033[2J\033[1;1H";
                cout <<  (double) (progress/ (double) inputfilesize) * 100 << "%" << endl;

                // for (int i = 0; i < 5; i++)
                // {
                //     char temp = c[i];
                //     c[i] = c[10-1-i];
                //     c[10-1-i] = temp;
                // }

                // Writing content into output file (need not reversed as buffer-size=1)
                lseek(inputfiledescriptor, -1, SEEK_CUR);
                write(outputfiledescriptor, d, 1);

                dumbsize-=1; 
            }           
        }
    }

    // Closing both input and output files
    close(inputfiledescriptor);
    close(outputfiledescriptor);
    return 0;
}
