git add *
git commit -m"Testing out stuff"
git push
