git add *
git commit -m"Regular Commit"
git push
